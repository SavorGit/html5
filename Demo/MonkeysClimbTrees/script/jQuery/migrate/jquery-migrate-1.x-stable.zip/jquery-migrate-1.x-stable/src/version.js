
jQuery.migrateVersion = "1.4.2-pre";
